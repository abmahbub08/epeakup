@extends('frontEnd.master')

@section('title','About Page')

@section('body')

<section id="intro" class="clearfix">
 
 <div class="container mt-5">

	<div class="row">


   <div class="col-md-12">
   <h2 class="text-center"><b>About epeakup.com</b></h2>

            <p>
            
               <b>Epeakup.com</b> is powered by Easily<b> Bkash</b>/ <b>Rocket</b> Payment and <b>Mobile Top Up</b> Service which has start at <b>Australia</b> and has been providing <b>Bkash</b>/ <b>Rocket</b> and <b>Mobile Top Up</b> Service in all major cities in <b>Australia </b>for the last few years. <br><br><br>

               <b>epeakup.com</b> is <b>Registered and regulated</b> by the rules and regulations governed by Australia. <br><br>

               Our company is managed by people who have extensive experience in<b> bkash/ Rocket & Mobile Top-Up</b>, consumer payments processing and data security. We understand how important each and every payment service is to our customers and are committed to earning your business. With in short time anyone can <b>bkash/ Rocket/ Mobile Top-up to Bangladesh</b>.


            </p>

         </div>
	</div>
</div>
</section>
@endsection